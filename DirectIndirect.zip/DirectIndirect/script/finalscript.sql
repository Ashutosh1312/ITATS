drop database if exists dn_directindirect;
create database  dn_directindirect;
use  dn_directindirect;


CREATE TABLE IF NOT EXISTS `adminregistration` (
  `txtId` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `contact_number` varchar(10) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`txtId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

insert into `adminregistration`(`full_name`,`contact_number`,`email_id`,`answer`,`password`)
value
('Admin','9876543210','admin@gmail.com','1234567','james@007');


CREATE TABLE IF NOT EXISTS `customerregistration` (
  `txtId` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `contact_number` varchar(10) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`txtId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

 
CREATE TABLE IF NOT EXISTS `loanapplication` (
  `txtId` int(11) NOT NULL AUTO_INCREMENT,
  `customerId` int(11) ,
  `panno` varchar(10) NOT NULL,
  `aadharno` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `altercontact` varchar(100) NOT NULL,
  `drivinglicense` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`txtId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

 