/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.servlet;

import com.main.services.MySqlConnection;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author yuvraj
 */
public class LoginProcess {

    public static ArrayList<LoanDTO> getLoanDetails() {
        ArrayList<LoanDTO> arrayList = new ArrayList<LoanDTO>();

        String sql = "SELECT * FROM `loanapplication` l, `customerregistration` c where l.`customerId` = c.txtId";
        try {
            ResultSet executeQuery = MySqlConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                LoanDTO loanDTO = new LoanDTO();
                
                loanDTO.setCustomerName(executeQuery.getString("full_name"));
                loanDTO.setContactNo(executeQuery.getString("contact_number"));
                loanDTO.setEmail(executeQuery.getString("email_id"));
                loanDTO.setPanno(executeQuery.getString("panno"));
                loanDTO.setAdharno(executeQuery.getString("aadharno"));
                
                arrayList.add(loanDTO);
            }
        } catch (Exception e) {
        }

        return arrayList;
    }

    public static void main(String[] args) {
        String loginAdmin = loginAdmin("admin@gmail.com", "james@007");
        System.out.println("loginAdmin = " + loginAdmin);
    }

    public static String loginAdmin(String username, String password) {
        String string = "";
        try {
            String sql = "SELECT *  FROM  `adminregistration` WHERE email_id = '" + username + "' AND password = '" + password + "'";
            System.out.println("sql = " + sql);
            ResultSet executeQuery = MySqlConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                string = executeQuery.getString(1);
                System.out.println("executeQuery = " + string);
            }
        } catch (Exception e) {
        }
        return string;
    }

    public static String loginPaitenet(String username, String password) {
        String string = "";
        try {
            String sql = "SELECT *  FROM  `customerregistration` WHERE email_id = '" + username + "' AND password = '" + password + "'";
            System.out.println("sql = " + sql);
            ResultSet executeQuery = MySqlConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                string = executeQuery.getString(1);
                System.out.println("executeQuery = " + string);
            }
        } catch (Exception e) {
        }
        return string;
    }

    public static String checkPaitent(String username) {
        String string = "";
        try {
            String sql = "SELECT txtId  FROM  `customerregistration` WHERE email_id = '" + username + "'";
            ResultSet executeQuery = MySqlConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                string = executeQuery.getString(1);
            }
        } catch (Exception e) {
        }
        return string;
    }

    public static String loginName(String username, String password) {
        String string = "";
        try {
            String sql = "SELECT full_name  FROM  `customerregistration` WHERE email_id = '" + username + "' AND password = '" + password + "'";
            System.out.println("sql = " + sql);
            ResultSet executeQuery = MySqlConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                string = executeQuery.getString("full_name");
                System.out.println("executeQuery = " + string);
            }
        } catch (Exception e) {
        }
        return string;
    }

    public static String loginAdminName(String username, String password) {
        String string = "";
        try {
            String sql = "SELECT full_name  FROM  `adminregistration` WHERE email_id = '" + username + "' AND password = '" + password + "'";
            System.out.println("sql = " + sql);
            ResultSet executeQuery = MySqlConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                string = executeQuery.getString("full_name");
                System.out.println("executeQuery = " + string);
            }
        } catch (Exception e) {
        }
        return string;
    }

}
