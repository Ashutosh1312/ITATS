DROP DATABASE IF EXISTS db_itats;
CREATE DATABASE db_itats;
USE db_itats;


CREATE TABLE IF NOT EXISTS `dataentry` (
  `id` int(10) NOT NULL,
  `category` varchar(40) NOT NULL,
  `type` varchar(40) NOT NULL,
  `nmae` varchar(40) NOT NULL,
  `city` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `charge` varchar(40) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;


INSERT INTO `dataentry` (`id`, `category`, `type`, `nmae`, `city`, `address`, `charge`) VALUES
(1, 'Tour', 'Hills Station', 'JAMSAVALI', 'NAGPUR', 'SHREE SHREE HANUMAN TEMPLE SAONER', '400'),
(2, 'Tour', 'Zoo', 'MAHARAJ BHAG', 'NAGPUR', 'NEAR SITABULDI NAGPUR', '50'),
(3, 'Tour', 'Temple', 'shree gajanan maharaj', 'NAGPUR', 'shree gajanan maharaj temple', '80'),
(4, 'Transpotation', 'Railway', 'duranto', 'NAGPUR', '', '600'),
(5, 'Transpotation', 'Bus', 'saini travelles', 'NAGPUR', '', '240'),
(6, 'Transpotation', 'Rikhsha', 'juganu', 'NAGPUR', '', '320'),
(7, 'Transpotation', 'Auto', 'zataka', 'NAGPUR', '', '350'),
(8, 'Hotel', 'hotel pride', '2 Star', 'NAGPUR', 'wardha road ', '1200'),
(9, 'Hotel', 'sun and sand', '3 Star', 'NAGPUR', 'near great nag road', '600'),
(10, 'Food', 'Maharastrian', 'pintu saoji', 'NAGPUR', 'near kalimata temple ', '550'),
(11, 'Food', 'Thali', 'sapana hotel', 'NAGPUR', 'near suprim quote', '600'),
(12, 'Transaction', 'ATM', 'bank of badoda', 'NAGPUR', 'near man mohan', 'N/A');


CREATE TABLE IF NOT EXISTS `datasearch` (
  `id` int(10) NOT NULL,
  `category` varchar(40) NOT NULL,
  `type` varchar(40) NOT NULL,
  `nmae` varchar(40) NOT NULL,
  `city` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `charge` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `tbl_registration` (
  `id` int(10) NOT NULL,
  `txtUserType` varchar(5) NOT NULL,
  `txtFirstName` varchar(500) DEFAULT NULL,
  `txtMobileNumber` varchar(500) DEFAULT NULL,
  `txtEmailId` varchar(500) DEFAULT NULL,
  `txtUserName` varchar(500) DEFAULT NULL,
  `txtPassword` varchar(500) DEFAULT NULL,
  `txtEntryDate` varchar(500) DEFAULT NULL,
  `txtIsActive` varchar(500) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


INSERT INTO `tbl_registration` (`id`, `txtUserType`, `txtFirstName`, `txtMobileNumber`, `txtEmailId`, `txtUserName`, `txtPassword`, `txtEntryDate`, `txtIsActive`) VALUES
(1, 'd', 'pravin tumsare', '7416363492', 'pravintumsare@gmail.com', 'pravintumsare@gmail.com', '123456', NULL, 'Y');

ALTER TABLE `dataentry`
  ADD PRIMARY KEY (`id`);

 
ALTER TABLE `datasearch`
  ADD PRIMARY KEY (`id`);

 
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataentry`
--
ALTER TABLE `dataentry`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `datasearch`
--
ALTER TABLE `datasearch`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
