/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.dto;

public class FoodDTO implements Comparable<FoodDTO> {

    public FoodDTO() {
    }

    public FoodDTO(DataentryDTO dataentryDTO) {
        this.nmae = dataentryDTO.getNmae();
        this.address = dataentryDTO.getAddress();
        this.charge = dataentryDTO.getCharge();
    }

    public FoodDTO(String nmae, String address, String charge) {
        this.nmae = nmae;
        this.address = address;
        this.charge = charge;
    }

    private String nmae;
    private String address;
    private String charge;

    public String getNmae() {
        return nmae;
    }

    public void setNmae(String nmae) {
        this.nmae = nmae;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCharge() {
        return charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    @Override
    public int compareTo(FoodDTO o) {
        int compareCharges = Integer.parseInt(((FoodDTO) o).getCharge());
        return Integer.parseInt(this.charge) - compareCharges;
    }

    @Override
    public String toString() {
        return getCharge() + "\t\t" + getNmae() + "\t\t" + getAddress();
    }
}
