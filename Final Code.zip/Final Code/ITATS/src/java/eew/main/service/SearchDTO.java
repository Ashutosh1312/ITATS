package eew.main.service;

public class SearchDTO {

    String city;
    String name;
    String type;
    String cost;

    public SearchDTO(String city, String name, String type, String cost) {
        this.city = city;
        this.name = name;
        this.type = type;
        this.cost = cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getCost() {
        return cost;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return getName() + "\t" + getType() + "\t" + getCost() + "\t" + getName();
    }

}
