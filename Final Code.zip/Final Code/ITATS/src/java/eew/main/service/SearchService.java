package eew.main.service;

import com.main.dto.DataentryDTO;
import com.main.dto.FoodDTO;
import com.main.dto.HotelDTO;
import com.main.dto.OptimizeDTO;
import com.main.dto.TourDTO;
import com.main.dto.TransportDTO;
import com.main.pojo.Dataentry;
import static eew.main.service.SuperConnection.session;
import static eew.main.service.SuperConnection.transaction;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class SearchService {

    public static void main(String[] args) {
        ArrayList<OptimizeDTO> optimizePlan = getOptimizePlan("nagpur", "2000");
        for (OptimizeDTO optimizeDTO : optimizePlan) {
            System.out.println("optimizeDTO = " + optimizeDTO.getCharges());
        }
    }

    public static ArrayList<OptimizeDTO> getOptimizePlan(String cityName, String charges) {
        ArrayList<OptimizeDTO> arrayList = new ArrayList<OptimizeDTO>();

        ArrayList<DataentryDTO> masterTranspotation = SearchService.masterSearch(cityName, charges, "Transpotation");
        ArrayList<DataentryDTO> masterTour = SearchService.masterSearch(cityName, charges, "Tour");
        ArrayList<DataentryDTO> masterFood = SearchService.masterSearch(cityName, charges, "Food");
        ArrayList<DataentryDTO> masterHotel = SearchService.masterSearch(cityName, charges, "Hotel");

        ArrayList<TransportDTO> masterTranspotationDTO = new ArrayList<TransportDTO>();
        for (DataentryDTO dataentryDTO : masterTranspotation) {
            masterTranspotationDTO.add(new TransportDTO(dataentryDTO));
        }

        ArrayList<TourDTO> masterTourDTO = new ArrayList<TourDTO>();
        for (DataentryDTO dataentryDTO : masterTour) {
            masterTourDTO.add(new TourDTO(dataentryDTO));
        }

        ArrayList<FoodDTO> masterFoodDTO = new ArrayList<FoodDTO>();
        for (DataentryDTO dataentryDTO : masterFood) {
            masterFoodDTO.add(new FoodDTO(dataentryDTO));
        }

        ArrayList<HotelDTO> masterHotelDTO = new ArrayList<HotelDTO>();
        for (DataentryDTO dataentryDTO : masterHotel) {
            masterHotelDTO.add(new HotelDTO(dataentryDTO));
        }

        Collections.sort(masterTranspotationDTO);
        Collections.sort(masterTourDTO);
        Collections.sort(masterFoodDTO);
        Collections.sort(masterHotelDTO);

        ArrayList<Integer> countList = new ArrayList<Integer>();
        countList.add(masterTranspotation.size());
        countList.add(masterTour.size());
        countList.add(masterFood.size());
        countList.add(masterHotel.size());
        Collections.sort(countList);
        Integer minSize = getMinSize(countList);

        for (int index = 0; index < minSize.intValue(); index++) {
            OptimizeDTO optimizeDTO = new OptimizeDTO();
            optimizeDTO.setFoodDTO(masterFoodDTO.get(index));
            optimizeDTO.setTransportDTO(masterTranspotationDTO.get(index));
            optimizeDTO.setTourDTO(masterTourDTO.get(index));
            optimizeDTO.setHotelDTO(masterHotelDTO.get(index));
            try {
                int foodCharge = Integer.parseInt(masterFoodDTO.get(index).getCharge());
                System.out.println("foodCharge = " + foodCharge);
                int transpotationCharge = Integer.parseInt(masterTranspotationDTO.get(index).getCharge());
                System.out.println("transpotationCharge = " + transpotationCharge);
                int tourCharge = Integer.parseInt(masterTourDTO.get(index).getCharge());
                System.out.println("tourCharge = " + tourCharge);
                int hotelCharge = Integer.parseInt(masterHotelDTO.get(index).getCharge());
                System.out.println("hotelCharge = " + hotelCharge);
                optimizeDTO.setCharges((foodCharge + transpotationCharge + tourCharge + hotelCharge) + "");
                System.out.println("");
                System.out.println("");
            } catch (Exception e) {
                optimizeDTO.setCharges(0 + "");
            }
            arrayList.add(optimizeDTO);
        }
        return arrayList;
    }

    public static int masterTotal(String type) {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        Criteria createCriteria = session.createCriteria(Dataentry.class);
        createCriteria.add(Restrictions.eq("category", type));
        List list = createCriteria.list();
        return list.size();
    }

    public static ArrayList<DataentryDTO> masterSearch(String city, String charge, String type) {
        session = HibernateConnection.getSessionFactory().openSession();
        transaction = session.beginTransaction();
        Criteria createCriteria = session.createCriteria(Dataentry.class);
        createCriteria.add(Restrictions.eq("city", city));
        createCriteria.add(Restrictions.eq("category", type));
        createCriteria.addOrder(Order.asc("charge"));
        createCriteria.setMaxResults(5);
        List list = createCriteria.list();
        ArrayList<DataentryDTO> arrayList = new ArrayList<DataentryDTO>();
        int srno = 1;
        for (Object object : list) {
            if (object instanceof Dataentry) {
                Dataentry dataentry = (Dataentry) object;
                DataentryDTO dTO = new DataentryDTO();
                try {
                    if (Integer.parseInt(dataentry.getCharge()) <= Integer.parseInt(charge)) {
                        arrayList.add(dTO.getDataentry(dataentry));
                    }
                } catch (Exception e) {
                }
            }
            srno++;
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    public static Integer getMinSize(ArrayList<Integer> arrayList) {
        Collections.sort(arrayList);
        return arrayList.get(0);
    }

    public static Integer getMaxSize(ArrayList<Integer> arrayList) {
        Collections.sort(arrayList);
        return arrayList.get(arrayList.size() - 1);
    }

}
