drop database if exists db_itats;
create database  db_itats;
use  db_itats;

-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2016 at 04:42 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_itats`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataentry`
--

CREATE TABLE `dataentry` (
  `id` int(11) NOT NULL,
  `category` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `nmae` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `charge` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dataentry`
--

INSERT INTO `dataentry` (`id`, `category`, `type`, `nmae`, `city`, `address`, `charge`) VALUES
(1, 'Tour', 'Hills Station', 'Name', 'city', 'das sd d', '12'),
(2, 'Tour', 'Romantic', 'Matheran', 'Mumbai ', 'Mumbai panvel', '1200'),
(3, 'Transpotation', 'Private Bus', 'Saini Bus', 'Nagpur ', '', '5000'),
(4, 'Hotel', 'Pride Hotel', '3 Star', 'Nagpur', '400', '3000'),
(5, 'Transaction', 'Banks', 'SBI', 'Mumbai ', 'khoperkerane', 'N/A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE `tbl_registration` (
  `id` int(11) NOT NULL,
  `txtUserType` varchar(30) DEFAULT NULL,
  `txtFirstName` varchar(30) DEFAULT NULL,
  `txtMobileNumber` varchar(30) DEFAULT NULL,
  `txtEmailId` varchar(30) DEFAULT NULL,
  `txtUserName` varchar(30) DEFAULT NULL,
  `txtPassword` varchar(30) DEFAULT NULL,
  `txtEntryDate` varchar(30) DEFAULT NULL,
  `txtIsActive` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_registration`
--

INSERT INTO `tbl_registration` (`id`, `txtUserType`, `txtFirstName`, `txtMobileNumber`, `txtEmailId`, `txtUserName`, `txtPassword`, `txtEntryDate`, `txtIsActive`) VALUES
(1, 'd', 'Pravin Tumsare ', '8828115980', 'pravintumsare@gmail.com', 'pravintumsare@gmail.com', '123456', NULL, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transporation`
--

CREATE TABLE `tbl_transporation` (
  `id` int(11) NOT NULL,
  `category` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `nmae` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `charge` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dataentry`
--
ALTER TABLE `dataentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_transporation`
--
ALTER TABLE `tbl_transporation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataentry`
--
ALTER TABLE `dataentry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_transporation`
--
ALTER TABLE `tbl_transporation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
