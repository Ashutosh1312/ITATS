/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.compare;

/**
 *
 * @author GCW
 */
public class LCWDTO {

    private String word;
    private String frequncy;

    public String getFrequncy() {
        return frequncy;
    }

    public void setFrequncy(String frequncy) {
        this.frequncy = frequncy;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }
}
