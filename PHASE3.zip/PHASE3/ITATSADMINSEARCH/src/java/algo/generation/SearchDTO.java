package com.main.generation;

public class SearchDTO {

    String city;
    String name;
    String type;

    public SearchDTO(String city, String type, String name) {
        this.city = city;
        this.type = type;
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
