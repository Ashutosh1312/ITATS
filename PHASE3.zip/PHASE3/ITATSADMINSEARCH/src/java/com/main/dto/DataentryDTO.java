package com.main.dto;

import com.main.pojo.Dataentry;

public class DataentryDTO implements Comparable<DataentryDTO> {

    private Integer id;
    private String category;
    private String type;
    private String nmae;
    private String city;
    private String address;
    private String charge;

    public DataentryDTO() {
    }

    public DataentryDTO(String category, String type, String nmae, String city, String address, String charge) {
        this.category = category;
        this.type = type;
        this.nmae = nmae;
        this.city = city;
        this.address = address;
        this.charge = charge;
    }

    public DataentryDTO getDataentry(Dataentry pojo) {
        return new DataentryDTO(pojo.getCategory(), pojo.getType(), pojo.getNmae(), pojo.getCity(), pojo.getAddress(), pojo.getCharge());
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCategory() {
        return this.category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNmae() {
        return this.nmae;
    }

    public void setNmae(String nmae) {
        this.nmae = nmae;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCharge() {
        return this.charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    @Override
    public String toString() {
        return (getCharge()).toUpperCase() + "\t\t" + getCategory() + "\t\t" + getNmae() + "\t\t" + getType();
    }

    @Override
    public int compareTo(DataentryDTO o) {
        try {
            String charge = ((DataentryDTO) o).getCharge();
            int comapreCharge = Integer.parseInt(charge);
            return Integer.parseInt(this.charge) - comapreCharge;
        } catch (Exception e) {
        }
        return -1;
    }

}
