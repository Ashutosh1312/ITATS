package com.main.pojo;

public class Dataentry implements java.io.Serializable {

    private Integer id;// ENCAPSULATION OF THE VARIABLE
    private String category;
    private String type;
    private String nmae;
    private String city;
    private String address;
    private String charge;

    public Dataentry() {
    }

    public Dataentry(String category, String type, String nmae, String city, String address, String charge) {
        this.category = category;
        this.type = type;
        this.nmae = nmae;
        this.city = city;
        this.address = address;
        this.charge = charge;
    }

    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCategory() {
        return this.category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNmae() {
        return this.nmae;
    }

    public void setNmae(String nmae) {
        this.nmae = nmae;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCharge() {
        return this.charge;
    }

    public void setCharge(String charge) {
        this.charge = charge;
    }

    @Override
    public String toString() {
        return getNmae() + "\t" + getType();
    }

}
