
import com.main.ext.services.SendEmailServices;
import com.main.ext.services.TemplateService;

public class TestEmail {

    public static void main(String[] args) {
        try {
            TemplateService templateService = new TemplateService();
            String emailTemplate = templateService.getEmailTemplate();
            System.out.println("email template:"+emailTemplate);
            SendEmailServices sendEmailServices = new SendEmailServices(emailTemplate, "eew.sagar@gmail.com");
            
            sendEmailServices.sucessRegistration();
            System.out.println("successfully send");
        } catch (Exception e) {
            System.out.println("something is wrong: " + e);
        }
    }

}
