/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eew.main.service;

import eew.main.application.IApplicationConstant;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author yuvraj
 */
public class LookUpService implements IApplicationConstant {

    public static ArrayList<String> getProjectLookUpList(String category) {
        ArrayList<String> arrayList = new ArrayList<String>();

        switch (1) {
            case 1:
                arrayList.add("WIRELESS SENSOR NETWORK");
                arrayList.add("DATA MINING");
                arrayList.add("DIGITAL SIGNAL PROCESSING");
                arrayList.add("ANDRIOD");
                arrayList.add("DIGITAL COMMUNICATIONS");
                arrayList.add("IMAGE PROCESSING");
                arrayList.add("CLOUD COMPUTING");
                arrayList.add("KNOWLEDGE AND DATA ENGINEERING");
                arrayList.add("WEB MINING");
                arrayList.add("NETWORKING");
                arrayList.add("NETWORK SECURITY");
                arrayList.add("STUDENT INTERNSHIP");
                arrayList.add("MOBILE COMPUTING");
                arrayList.add("PARALLEL AND DISTRIBUTED SYSTEMS");
                break;
            case 2:
                arrayList.add("JAVA");
                arrayList.add("PHP");
                arrayList.add("MATLAB");
                arrayList.add("NS-2");
                arrayList.add("NS-3");
                arrayList.add("ANDROID");
                arrayList.add("AWT");
                arrayList.add("SWING");
                arrayList.add("JSP");
                arrayList.add("HTML");
                break;
            case 3:
                arrayList.add("MTECH");
                arrayList.add("BTECH");
                arrayList.add("PLOY");
                arrayList.add("MCA");
                arrayList.add("BCA");
                arrayList.add("CLIENT");
                arrayList.add("OTHER");
                break;
        }
        Collections.sort(arrayList);
        return arrayList;
    }
}
