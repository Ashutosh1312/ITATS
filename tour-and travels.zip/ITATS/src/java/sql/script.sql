drop database if exists db_itats;
create database  db_itats;
use  db_itats;

create table dataentry(
    `id` int(11) primary key auto_increment,
    `category` varchar(30),
    `type` varchar(30),
    `nmae` varchar(30),
    `city` varchar(30),
    `address` varchar(300),
    `charge`  varchar(30)
);
 
create table tbl_registration(
    `id` int(11) primary key auto_increment,
     txtUserType varchar(30),
     txtFirstName varchar(30),
     txtMobileNumber varchar(30),
     txtEmailId varchar(30),
     txtUserName varchar(30),
     txtPassword varchar(30),
     txtEntryDate varchar(30),
     txtIsActive  varchar(1)
);

